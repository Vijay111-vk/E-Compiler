/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "ulimitedrational.h"
#include <iostream>
UnlimitedInt* gcd(UnlimitedInt* i1, UnlimitedInt* i2){
    UnlimitedInt* a=new UnlimitedInt(i1->to_string());
    UnlimitedInt* b=new UnlimitedInt(i2->to_string());
    // *a=*i1;
    // *b=*i2; 
    // cout<<b->to_string();
    if (b->to_string() == "0" ) {
        // cout<<":dddd1";
        return a;
    } 
    else {
        // cout<<":dddd";
        // cout<<UnlimitedInt::mod(a,b)->to_string()<<endl;
        return gcd(b, UnlimitedInt::mod(a,b));
    }
} 
UnlimitedRational::UnlimitedRational(){
    p=new UnlimitedInt(0);
    q=new UnlimitedInt(1);
}
UnlimitedRational::UnlimitedRational(UnlimitedInt* num, UnlimitedInt* den){
    if(den->get_size()==1&&den->get_array()[0]==0){
        p=new UnlimitedInt(0);
        q=new UnlimitedInt(0);
    } 
    else{ 
        p=num;
        q=den;
        // cout<<"c1"<<endl;
        UnlimitedInt* common = gcd(p,q);

        // cout<<"c2"<<endl;
        // cout<<p->to_string()<<endl;
        p=UnlimitedInt::div(p,common); 
        // cout<<p->to_string()<<endl;
        q=UnlimitedInt::div(q, common);
        // cout<<q->to_string()<<endl;
        // cout<<"created successfully"<<endl;
    }
    // delete num;
    // delete den;
} 




// UnlimitedInt* gcd(UnlimitedInt* a, UnlimitedInt* b){
//     if (b->get_array()[0] == 0 && b->get_size()==1) {
//         return a;
//     } 
//     else {
//         UnlimitedInt* temp=gcd(b, UnlimitedInt::mod(a,b));
//         // delete a;
//         delete b;
//         return temp;
//     }
// }

// UnlimitedRational::UnlimitedRational(UnlimitedInt* num, UnlimitedInt* den){
//     UnlimitedInt* p1=new UnlimitedInt(num->to_string());
//     UnlimitedInt* q1=new UnlimitedInt(den->to_string());
    
//     while (den->get_sign()!=0 || den->to_string()[0]!='0')
//     {
//         UnlimitedInt* temp=den;
//         den=num->mod(num,den);
//         num=temp;
//     }
//     p=p1->div(p1,num);
//     q=q1->div(q1,num);
//     delete p1;
//     delete q1;
// }

UnlimitedRational::~UnlimitedRational() {
    delete p;
    delete q;
}
UnlimitedInt* UnlimitedRational::get_p() {
    return p;
}

UnlimitedInt* UnlimitedRational::get_q() {
    return q;
} 

string UnlimitedRational::get_p_str() {
    return p->to_string();
}

string UnlimitedRational::get_q_str() {
    return q->to_string();
}

string UnlimitedRational::get_frac_str() {
    return p->to_string() + "/" + q->to_string();
}

UnlimitedRational* UnlimitedRational::add(UnlimitedRational* i1, UnlimitedRational* i2){
    UnlimitedInt* p1 = i1->get_p();
    UnlimitedInt* q1 = i1->get_q();
    UnlimitedInt* p2 = i2->get_p();
    UnlimitedInt* q2 = i2->get_q();
    UnlimitedInt* h1=UnlimitedInt::mul(p1, q2);
    // cout<<h1->to_string()<<endl;
    UnlimitedInt* h2=UnlimitedInt::mul(p2, q1);
    // cout<<h2->to_string()<<endl;
    UnlimitedInt* numerator = UnlimitedInt::add(h1,h2);
    // cout<<numerator->to_string()<<endl;
    UnlimitedInt* denominator = UnlimitedInt::mul(q1, q2);
    // cout<<denominator->to_string()<<endl;
    // UnlimitedRational(numerator, denominator);
    // delete p1;
    // delete q1;
    // delete p2;
    // delete q2; 
    UnlimitedRational* r=new UnlimitedRational(numerator, denominator);
    // cout<<r->get_frac_str()<<endl;
    return r;
}
UnlimitedRational* UnlimitedRational::sub(UnlimitedRational* i1, UnlimitedRational* i2){
    UnlimitedInt* p1 = i1->get_p();
    UnlimitedInt* q1 = i1->get_q();
    UnlimitedInt* p2 = i2->get_p();
    UnlimitedInt* q2 = i2->get_q();
    UnlimitedInt* numerator = UnlimitedInt::sub(UnlimitedInt::mul(p1, q2),  UnlimitedInt::mul(p2, q1));
    UnlimitedInt* denominator = UnlimitedInt::mul(q1, q2);
    // UnlimitedRational(numerator, denominator);
    // delete p1;
    // delete q1;
    // delete p2;
    // delete q2;
    UnlimitedRational* r=new UnlimitedRational(numerator, denominator);
    return r;
}
UnlimitedRational* UnlimitedRational::mul(UnlimitedRational* i1, UnlimitedRational* i2){
    UnlimitedInt* p1 = i1->get_p();
    UnlimitedInt* q1 = i1->get_q();
    UnlimitedInt* p2 = i2->get_p();
    UnlimitedInt* q2 = i2->get_q();
    UnlimitedInt* numerator = UnlimitedInt::mul(p1, p2); 
    // cout<<numerator->to_string()<<endl;
    UnlimitedInt* denominator = UnlimitedInt::mul(q1, q2);
    // cout<<denominator->to_string()<<endl;
    // UnlimitedRational(numerator, denominator);
    // delete p1;
    // delete q1;
    // delete p2;
    // delete q2;
    UnlimitedRational* r=new UnlimitedRational(numerator, denominator);
    return r;
}
UnlimitedRational*UnlimitedRational::div(UnlimitedRational* i1, UnlimitedRational* i2){
    UnlimitedInt* p1 = i1->get_p();
    UnlimitedInt* q1 = i1->get_q();
    UnlimitedInt* p2 = i2->get_p();
    UnlimitedInt* q2 = i2->get_q();
    UnlimitedInt* numerator = UnlimitedInt::mul(p1, q2); 
    UnlimitedInt* denominator = UnlimitedInt::mul(q1, p2);
    // UnlimitedRational(numerator, denominator);
    // delete p1;
    // delete q1;
    // delete p2;
    // delete q2;
    UnlimitedRational* r=new UnlimitedRational(numerator, denominator);
    return r;
}


// int main(){
// //     // UnlimitedRational* p=UnlimitedRational::mul(new UnlimitedRational(new UnlimitedInt("526848"),new UnlimitedInt("815730721")),new UnlimitedRational(new UnlimitedInt("42"),new UnlimitedInt("1")));
// //     // UnlimitedRational* q=UnlimitedRational::mul(new UnlimitedRational(new UnlimitedInt("13"),new UnlimitedInt("1")),new UnlimitedRational(new UnlimitedInt("13"),new UnlimitedInt("1")));
//     // UnlimitedRational* p=new UnlimitedRational(new UnlimitedInt("665416609183179841"),new UnlimitedInt("277568815401"));
//     // cout<<p->get_frac_str()<<endl;
//     // UnlimitedInt* u2=new UnlimitedInt("2775690");
//     // UnlimitedInt* u1=new UnlimitedInt("665416618323333");
//     UnlimitedRational* p=new UnlimitedRational(new UnlimitedInt("63"),new UnlimitedInt("1"));
//     UnlimitedRational* q=new UnlimitedRational(new UnlimitedInt("7"),new UnlimitedInt(1));
//     //  UnlimitedRational* t=new UnlimitedRational(new UnlimitedInt(1330),new UnlimitedInt(51));
//     UnlimitedRational* c = c->sub(p,q);
//     // delete p;
//     // delete q;
//     // UnlimitedInt* p=new UnlimitedInt("526848");
//     // UnlimitedInt* q=new UnlimitedInt("526848");
//     // cout<<gcd(u1,u2)->to_string();
//     cout<<c->get_frac_str()<<endl;
//     // cout<<q->get_frac_str()<<endl;
// }