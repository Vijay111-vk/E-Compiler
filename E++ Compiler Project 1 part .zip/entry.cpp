/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "entry.h"
SymEntry::SymEntry(){
    left=nullptr;
    right=nullptr;
    val=nullptr;
    key="";
}
SymEntry::SymEntry(string k, UnlimitedRational* v){
    left=nullptr;
    right=nullptr;
    val=v;
    key=k;
}

SymEntry::~SymEntry(){
    delete left;
    delete right;
    delete val;
}