/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "ulimitedint.h"
#include <iostream>

UnlimitedInt::UnlimitedInt(){
    size=0;
    capacity=10;
    sign=1;
    unlimited_int = new int[capacity];
}
UnlimitedInt::UnlimitedInt(string s){
    size=0;
    if(s[0]=='-'){
        sign=-1;
        s=s.substr(1);
    }
    else{
        sign=1; 
    }
    capacity=s.length(); 
    unlimited_int = new int[capacity];
    for(int i = 0; i < capacity; i++){
        unlimited_int[size] = s[i]-'0'; 
        size++;
    } 
} 
UnlimitedInt::UnlimitedInt(int i){ 
    if(i<0){
        sign=-1;
        i=-i;
    }
    else{
        sign=1;
    }
    size=0;
    int y=i;
    int z=i;
    capacity=0;
    while(y>0){
        y=y/10;
        capacity ++;
    }
    if(i==0){
        capacity=1;
    }
    int x=capacity;
    unlimited_int = new int[capacity];
    for(int i=0; i<capacity; i++){
        unlimited_int[x-1]=z%10;
        z=z/10;
        x=x-1;
        size++;
    }
}
UnlimitedInt::UnlimitedInt(int* ulimited_int, int cap, int sgn, int sz){
    size=sz;
    sign=sgn;
    capacity=cap;
    unlimited_int = ulimited_int;
}
UnlimitedInt::~UnlimitedInt(){
    delete[] unlimited_int;
}
int UnlimitedInt::get_size(){
    return size;
}
int* UnlimitedInt:: get_array(){
    return unlimited_int;
}
int UnlimitedInt::get_sign(){
    return sign;
}
int UnlimitedInt::get_capacity(){
    return capacity;
}
string UnlimitedInt::to_string(){
    // if(size==0){
    //     return "0";
    // }
    string s="";
    string s1="0123456789";
    if(sign==-1){
        s=s+"-";
        for(int i=0; i<size;i++){
            for(int j=0; j<10; j++){
                if(unlimited_int[i]==s1[j]-'0'){
                    s=s+s1[j];
                }
            }
        }
    } 
    else{
    for(int i=0; i<size;i++){
        for(int j=0; j<10; j++){
            if(unlimited_int[i]==s1[j]-'0'){
                s=s+s1[j];
            }
        }
    } 
    }
    return s;
}




UnlimitedInt* UnlimitedInt::add(UnlimitedInt* i3, UnlimitedInt* i4){
    UnlimitedInt* i1= new UnlimitedInt();
    UnlimitedInt* i2= new UnlimitedInt();
    *i1=*i3;
    *i2=*i4;
    int sign1 = i1->get_sign();
    int sign2 = i2->get_sign();
//where is case of if i2=0 and i1 is something ?
//think for difference between capacity and size
    int size1=i1->get_size();
    int size2=i2->get_size();
    int size=max(size1, size2)+1;
    int* ans = new int[size]; 
    ans[0]=0;
    int i,j;
    int carry=0;
    int digit1,digit2,digit;
    int x=size;
    int sign;
    int capacity = size; 
    for (i = size1 - 1, j = size2 - 1; i >= 0 && j >= 0; i--, j--){
        digit1=i1->get_array()[i];
        digit2=i2->get_array()[j];
        digit=digit1+digit2+carry;
        carry=digit/10;
        digit=digit%10;
        ans[x-1]=digit;
        x--;
    }
    
    while(i>=0){
        digit1=i1->get_array()[i];
        digit=digit1+carry;
        carry=digit/10;
        digit=digit%10;
        ans[x-1]=digit;
        x--;
        i--;
    }
    
    while(j>=0){
        digit2=i2->get_array()[j];
        digit=digit2+carry;
        carry=digit/10;
        digit=digit%10;
        ans[x-1]=digit;
        x--;
        j--;
    }
    if(carry!=0&&(size1==size2)){
        ans[0]=carry;
    }
    
    if(ans[0]==0){
        int* newans = new int[size-1];
        for(int p=0; p<size-1; p++){
            newans[p]=ans[p+1];
        }
        ans=newans;
        size=size-1;
        // delete[] newans;
    }
    if(sign1==1&&sign2==1){
        sign=1;
    }
    if(sign1==-1&&sign2==-1){
        sign=-1;
    } 
    if(sign1==1&&sign2==-1){
        UnlimitedInt* i5=new UnlimitedInt();
        *i5=*i2;
        i5->sign=1;
        return sub(i1,i5);
    }
    if(sign1==-1&&sign2==1){
        UnlimitedInt* i5=new UnlimitedInt();
        *i5=*i2;
        i5->sign=-1;
        return sub(i1,i5);
    }
    return new UnlimitedInt(ans, capacity, sign, size);
}




UnlimitedInt* UnlimitedInt::sub(UnlimitedInt* i3, UnlimitedInt* i4){
    UnlimitedInt* i1= new UnlimitedInt();
    UnlimitedInt* i2= new UnlimitedInt();
    *i1=*i3;
    *i2=*i4;
    int sign1 = i1->get_sign();
    int sign2 = i2->get_sign();
//where is case of if i2=0 and i1 is something ?
    int size1=i1->get_size();
    int size2=i2->get_size();
    int size=max(size1, size2);
    int* ans = new int[size]; 
    for(int i=0;i<size;i++){
        ans[i]=0;
    }
    int carry=10;
    int digit1,digit2,digit;
    int x=size;
    int sign;
    int capacity = size; 
    if((sign1==1&&sign2==1)||(sign1==-1&&sign2==-1)){
        if(size1>size2){
            int i,j; 
            int k=0;
            if(sign1==1&&sign2==1){
                sign=1;
            }
            if(sign1==-1&&sign2==-1){
                sign=-1;
            }
            for ( i = size1 - 1, j = size2 - 1; i >= 0 && j >= 0; i--, j--){
                digit1=i1->get_array()[i];
                digit2=i2->get_array()[j];
                if(digit1>digit2){
                    digit=digit1-digit2;
                }
                if(digit1<digit2){
                    digit=digit1-digit2+carry;
                    i1->get_array()[i-1]=i1->get_array()[i-1]-1;
                }
                if(digit1==digit2){
                    digit=0;
                }
                ans[x-1]=digit;
                x--;
            }
            while(i>=0){
                digit1=i1->get_array()[i];
                if(digit1<0){
                    digit1+=carry;
                    i1->get_array()[i-1]=i1->get_array()[i-1]-1;
                }
                digit=digit1;
                ans[x-1]=digit;
                i--;
                x--;
            } 
            while(ans[0]==0){ 
                int* newans = new int[size-1];
                for(int p=0; p<size-1; p++){
                    newans[p]=ans[p+1];
                }
                ans=newans;
                size--;
                k++;
                // delete[] newans;
            } 
        }
        if(size1<size2){
            int i,j; 
            int k=0;
            if(sign1==1&&sign2==1){
                sign=-1;
            }
            if(sign1==-1&&sign2==-1){
                sign=1;
            }
            for ( i = size1 - 1, j = size2 - 1; i >= 0 && j >= 0; i--, j--){
                digit1=i1->get_array()[i];
                digit2=i2->get_array()[j];
                if(digit2>digit1){
                    digit=digit2-digit1;
                }
                if(digit2<digit1){
                    digit=digit2-digit1+carry;
                    i2->get_array()[j-1]=i2->get_array()[j-1]-1;
                }
                if(digit2==digit1){
                    digit=0;
                }
                ans[x-1]=digit;
                x--;
            }
            while(j>=0){
                digit2=i2->get_array()[j];
                if(digit2<0){
                    digit2+=carry;
                    i2->get_array()[j-1]=i2->get_array()[j-1]-1;
                }     
                digit=digit2;
                ans[x-1]=digit;
                j--; 
                x--;
            } 
            while(ans[0]==0){ 
                int* newans = new int[size-1];
                for(int p=0; p<size-1; p++){
                    newans[p]=ans[p+1];
                }
                ans=newans;
                size--;
                k++;
                // delete[] newans;
            }
        }
        if(size1==size2){
            for(int i=0; i< size1; i++){
                if(i1->get_array()[i]>i2->get_array()[i]){
                    if(sign1==1&&sign2==1){
                        sign=1;
                    }
                    if(sign1==-1&&sign2==-1){
                        sign=-1;
                    }
                    for(int j=size1-1; j>=0; j--){
                        digit1=i1->get_array()[j];
                        digit2=i2->get_array()[j];
                        if(digit1>digit2){
                            digit=digit1-digit2;
                        } 
                        if(digit1<digit2){
                            digit=digit1-digit2+carry;
                            i1->get_array()[j-1]=i1->get_array()[j-1]-1;
                        }
                        if(digit1==digit2){
                            digit=0;
                        }
                        ans[x-1]=digit;
                        x--;
                    }
                    int u=0;
                    while(ans[0]==0){
                        int* newans = new int[size-1];
                        for(int p=0; p<size-1; p++){
                            newans[p]=ans[p+1];
                        } 
                        ans=newans;
                        size--;
                        u++;
                        // delete[] newans;
                    }
                    break;
                }
                if(i1->get_array()[i]<i2->get_array()[i]){
                    if(sign1==1&&sign2==1){
                        sign=-1;
                    }
                    if(sign1==-1&&sign2==-1){
                        sign=1;
                    }
                    for(int j=size1-1; j>=0; j--){
                        digit1=i1->get_array()[j];
                        digit2=i2->get_array()[j];
                        if(digit2>digit1){
                            digit=digit2-digit1;
                        } 
                        if(digit2<digit1){
                            digit=digit2-digit1+carry;
                            i2->get_array()[j-1]=i2->get_array()[j-1]-1;
                        }
                        if(digit1==digit2){
                            digit=0;
                        }
                        ans[x-1]=digit;
                        x--;
                    }
                    int u=0;
                    while(ans[0]==0){
                        int* newans = new int[size-1];
                        for(int p=0; p<size-1; p++){
                            newans[p]=ans[p+1];
                        } 
                        ans=newans;
                        size--;
                        u++;
                        // delete[] newans;
                    }
                    break;
                }
                if((i1->get_array()[i]==i2->get_array()[i])&&(i==size1-1)){
                    ans[0]=0;
                    size=1;
                    capacity=2;
//capacity dountttttttttttttttttttttt    sign is 0 below see::::|
                    sign=0;
                    break;
                }
            }
        }   
    }
    if(sign1==1&&sign2==-1){
        UnlimitedInt* i5=new UnlimitedInt();
        *i5=*i2;
        i5->sign=1;
        return add(i1,i5);
    }
    if(sign1==-1&&sign2==1){
        UnlimitedInt* i5=new UnlimitedInt();
        *i5=*i2;
        i5->sign=-1;
        return add(i1,i5);
    }
    return new UnlimitedInt(ans,capacity,sign,size);
}



UnlimitedInt* UnlimitedInt::mul(UnlimitedInt* i1, UnlimitedInt* i2){
    int sign1 = i1->get_sign();
    int sign2 = i2->get_sign();
    int size1 = i1->get_size();
    int size2 = i2->get_size();
    int sign=sign1*sign2;
    int carry=0;
    int capacity=size1+size2;
    int size=capacity;
    int* ans =new int[capacity];
    int prod;
    for(int y=0; y<capacity; y++){
        ans[y]=0;
    }
    for(int i=size1-1; i>=0;i--){
        for(int j=size2-1;j>=0;j--){
            prod=i1->get_array()[i]*i2->get_array()[j];
            ans[i+j+1]+=prod;
        }
    }
    for(int x=size-1; x>=0; x--){
      int digit = (ans[x] + carry)%10;
      carry = (ans[x]+carry)/10;
      ans[x]=digit;
    }
    while(ans[0]==0){ 
        int* newans = new int[size-1];
        for(int p=0; p<size-1; p++){
            newans[p]=ans[p+1];
        } 
        ans=newans;
        size--;
        if(size==1&&ans[0]==0){
            sign=1;
            break;
        }
    }
    return new UnlimitedInt(ans,capacity,sign,size);
}

UnlimitedInt* UnlimitedInt::div(UnlimitedInt* i5, UnlimitedInt* i7){
    UnlimitedInt* i1=new UnlimitedInt;
    UnlimitedInt* i2=new UnlimitedInt; 
    *i1=*i5;
    *i2=*i7;
    if(i1->sign==-1||i2->sign==-1){
        i1->sign=1;
        i2->sign=1;
    }
    string s1= i1->to_string();
    string s2= i2->to_string();
    int size1=i1->size;
    string s ="";
    UnlimitedInt* i3=new UnlimitedInt(s);
    int size=0;
    int sign=1;
    int* ans =new int[size];
    if(s1==s2){
        UnlimitedInt* w = new UnlimitedInt(1);
        return w;
    }
    else if((s2.size()>s1.size()) || (s2.size()==s1.size() && (s2>s1))){
        UnlimitedInt* u=new UnlimitedInt(0);
        return u;
    }
    else if(i1->get_array()[0] ==0 && i1->size==1){
        return i1;
    }
    else{
        for(int i=0; i < size1 ; i++){
            int val=0;
            s=s+s1[i];
            i3 = new UnlimitedInt(s);
            while((s.size()>s2.size()) || (s.size()==s2.size() && (s>s2))||s==s2){
                i3=sub(i3, i2);
                s=i3->to_string();
                val++;
            }
            if(s=="0"){
                s="";
            }
            ans[size]=val;
            size++;
        }
    }
    while(ans[0]==0){ 
        int* newans = new int[size-1];
        for(int p=0; p<size-1; p++){
            newans[p]=ans[p+1];
        } 
        ans=newans;
        size--;
        if(size==1&&ans[0]==0){
            sign=1;
            break;
        }
    }
    int capacity=size+1;
    if(i5->sign==-1&&i7->sign==1){
        sign=-1;
        UnlimitedInt* finalans = new UnlimitedInt(ans, capacity, sign, size);
        UnlimitedInt* dx = new UnlimitedInt(-1);
        finalans=add(finalans, dx );
        return finalans;
    }
    if(i5->sign==1&&i7->sign==-1){
        sign=-1;
        UnlimitedInt* finalans = new UnlimitedInt(ans, capacity, sign, size);
        UnlimitedInt* dx = new UnlimitedInt(-1);
        finalans=add(finalans, dx );
        return finalans;
    }
    return new UnlimitedInt(ans, capacity, sign, size);
}


UnlimitedInt* UnlimitedInt::mod(UnlimitedInt* i3, UnlimitedInt* i4){
    UnlimitedInt* i1=new UnlimitedInt;
    UnlimitedInt* i2=new UnlimitedInt;
    *i1=*i3;
    *i2=*i4; 
    if(i1->sign==-1||i2->sign==-1){
        i1->sign=1;
        i2->sign=1;
    } 
    UnlimitedInt* ans = new UnlimitedInt();
    ans=sub(i1,mul(i2, div(i1,i2)));
    if (i3->sign == -1 && i4->sign == -1) {
        ans->sign = -1;
    }
    else if (i3->sign == -1) {
        ans = sub(ans, new UnlimitedInt(1));
    }
    else if (i4->sign == -1) {
        ans->sign = -1;
        ans = sub(ans, new UnlimitedInt(1));
    }
    return ans;
}

// int main(){
//     UnlimitedInt* u2=new UnlimitedInt("1");
//     UnlimitedInt* u1=new UnlimitedInt("1330");
// // UnlimitedInt* u1 = new UnlimitedInt("277568815401");
//     // cout << u1->get_sign() << endl;
//     // cout << u1->get_size() << endl;
//     // cout << u1->to_string() << endl;
//     // cout<<multipilier("815730721","815730721")<<endl;

// // UnlimitedInt* u2 = new UnlimitedInt(multipilier("815730721","815730721"));
//     // cout << u2->get_sign() << endl;
//     // cout << u2->get_size() << endl;
//     // cout << u2->to_string() << endl;
    
//     // UnlimitedInt* u;
//     // u = gcd(u1, u2);
//     // cout << u->get_sign() << endl;
//     // cout << u->get_size() << endl;
//     // cout << u->to_string() << endl;
   
    
//     UnlimitedInt* u4 = UnlimitedInt::div(u1, u2);
//     cout << u4->get_sign() << endl;
//     cout << u4->get_size() << endl;
//     cout << u4->UnlimitedInt::to_string() << endl;
//     // cout<<multipilier("5","15");
//     // UnlimitedInt* u5 = UnlimitedInt::mul(u1, u2);
// //     cout << u5->get_sign() << endl;
// //     cout << u5->get_size() << endl;
//     // cout << u5->UnlimitedInt::to_string() << endl;

//     UnlimitedInt* u6=UnlimitedInt::mul(u2,u1);
//     cout << u6->get_sign() << endl;
//     cout << u6->get_size() << endl;
//     cout << u6->UnlimitedInt::to_string() << endl;

    
//     return 0;
// }